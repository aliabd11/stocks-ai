import sys

from stocks_csp import *
#from propagators import *
from orderings import *

#data_set =

if __name__ == "__main__":
    #various user test-cases user1_dict = {'volume_to_buy': 30, 'green': 1, 'industry': 'Technology',
    #'spending_limit': 1, 'min_stock_price': 25, 'max_stock_price': 500,'region': 'Canada'}
    
    #argv1: beliefs (be: everything, ba: no alcohol, bw: no weapons, bg: no gambling)
    #argv2: region (rc: canada, ru: united states, re: everything)
    #argv3: sector (st: tech, sh: health)
    #argv4: flavour (fs: stocks, fbo: bonds, fbf: balanced funds)
    #argv5: desired style (as per style box, l/m/s+v/b/g
        #(large/mid/small+value/blend/growth)) ex. lg for large and growth
    #argv4: y/n to high management fees (y: okay with high fees, n: not okay)

